﻿internal class Program
{
    public const double PI = 3.1416;
    private static void Main(string[] args)
    {
        double c, r, volSquare, volCiecle, lostPercentage;
        Console.WriteLine("Put the length of the square:");
        c = Convert.ToDouble(Console.ReadLine());
        r = c / 2.0;
        volSquare = c * c;
        volCiecle = PI * Math.Pow(r, 2);
        lostPercentage = volCiecle * 100 / volSquare -100;
        lostPercentage = -lostPercentage;
        Console.WriteLine("The Percentage lost is: " + Math.Round(lostPercentage,2));
    }
}