﻿internal class Program
{
    private static void Main(string[] args)
    {
        double a, b, x;
        Console.WriteLine("Solucionant equació ax + b = 0");
        Console.WriteLine("Valor DEL 1er DAU -->");
        a = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Valor DEL 1er DAU -->");
        b = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Equacio {0}x+({1})=0", a,b);
        if (a != 0)
        {
            a = Math.Round(a, 2);
            b = Math.Round(b, 2);
            x = Math.Round(-b / a, 2);
            Console.WriteLine("Solucio x={0}", x);
        }
        else Console.WriteLine("No te solucio. El coeficient a no pot ser 0");
    }
}