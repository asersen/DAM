﻿internal class Program
{
    private static void Main(string[] args)
    {
        Random r = new Random();
        int primerDau, segonDau, tercerDau;
        int suma;
        Console.Clear();
        Console.WriteLine("SIMULACIÓ DEL LLENÇAMENT DE 3 DAUS I OBTENCIÓ DE LA SUMA DELS LLENÇAMENTS ");
        primerDau = r.Next(1, 7);
        segonDau = r.Next(6)+1;
        tercerDau = r.Next(6)+1;
        suma = primerDau + segonDau + tercerDau;
        Console.WriteLine("Valor DEL 1er DAU --> " + primerDau);
        Console.WriteLine("Valor DEL 2n DAU --> " + segonDau);
        Console.WriteLine("Valor DEL 3er DAU --> " + tercerDau);
        Console.WriteLine("Valor DELS 3 LLENÇAMENTS  --> " + suma);

    }
}