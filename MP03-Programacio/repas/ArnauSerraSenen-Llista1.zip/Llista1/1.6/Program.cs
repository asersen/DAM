﻿internal class Program
{
    public const double IVA = 0.21;
    private static void Main(string[] args)
    {
        double importBrut , iva , importNet, rawPrice, discount;
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.Write("Import brut de la venda -->");
        importBrut = Math.Round(Convert.ToDouble(Console.ReadLine()), 2);
        Console.Write("Percentatge de descompte (0 a 100) -->");
        rawPrice = Math.Round(Convert.ToDouble(Console.ReadLine()), 2);

        discount = importBrut * rawPrice / 100;
        Console.WriteLine("Import venda: \t\t" + importBrut + "€");
        importBrut = importBrut - discount;
        iva = Math.Round(importBrut * IVA, 2);
        importNet = importBrut + iva;
        Console.WriteLine("Descompte("+rawPrice+"%): \t" + discount + "€");
        Console.WriteLine("Import venda sense IVA: " + importBrut + "€");
        Console.WriteLine("IVA(" + IVA * 100 + "%) \t\t" + iva + "€");
        Console.WriteLine("Import final: \t\t" + importNet + "€");
    }
}